
from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.api import deps
from app.schemas.auth import LoginRequest, Token, UserCreate, UserOut
from app.services.auth_service import auth_service
from app.services.google_auth import google_auth_service
from app.core.response import APIResponse
from app.core.config import settings
from app.models.account import User

# Router đăng nhập truyền thống
router = APIRouter()

# Router riêng cho Google OAuth
google_router = APIRouter()

@router.post("/login")
def login(request_data: LoginRequest, db: Session = Depends(deps.get_db)):
    """Xác thực học sinh qua username/password."""
    result = auth_service.authenticate_student(
        db, 
        username=request_data.username, 
        password=request_data.password
    )
    return APIResponse.success(data=result)

@router.post("/register")
def register(user_in: UserCreate, db: Session = Depends(deps.get_db)):
    """Đăng ký tài khoản học sinh mới."""
    result = auth_service.register_student(db, user_in=user_in)
    return APIResponse.success(data=result, message="Đăng ký tài khoản thành công")

@router.get("/me", response_model=APIResponse[UserOut])
def get_me(current_user: User = Depends(deps.get_current_user)):
    """Lấy thông tin tài khoản hiện tại."""
    return APIResponse.success(data=current_user)

@google_router.get("/google/login")
def google_login():
    """Điều hướng trình duyệt sang Google OAuth 2.0 server."""
    auth_url = google_auth_service.get_google_auth_url()
    return RedirectResponse(auth_url)

@google_router.get("/google/callback")
async def google_callback(code: str, db: Session = Depends(deps.get_db)):
    """Tiếp nhận code từ Google, thực hiện verify và redirect về Frontend kèm Token."""
    jwt_token = await google_auth_service.verify_and_login(db, code)
    
    # Redirect về Frontend (LoginPage) kèm token trong query string
    # Frontend sẽ nhận token này và thực hiện đăng nhập vào Dashboard
    redirect_url = f"{settings.FRONTEND_URL}/login?token={jwt_token}"
    return RedirectResponse(redirect_url)
