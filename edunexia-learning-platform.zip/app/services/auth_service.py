
from sqlalchemy.orm import Session
from app.models.account import User
from app.core.security import verify_password, create_access_token, get_password_hash
from app.core.exceptions import AuthException, BusinessLogicException
import secrets
from app.schemas.auth import UserCreate

class AuthService:
    @staticmethod
    def authenticate_student(db: Session, username: str, password: str):
        user = db.query(User).filter(User.username == username).first()
        if not user:
            raise AuthException("Tài khoản không tồn tại")
        
        if not verify_password(password, user.hashed_password):
            raise AuthException("Thông tin đăng nhập không đúng")
        
        if not user.is_active:
            raise AuthException("Tài khoản bị khóa")
        
        token = create_access_token(subject=user.id)
        # Chuyển đổi sang dict để Pydantic có thể serialize dễ dàng
        user_data = {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "is_active": user.is_active
        }
        return {
            "access_token": token,
            "token_type": "bearer",
            "user": user_data
        }

    @staticmethod
    def register_student(db: Session, user_in: UserCreate):
        if db.query(User).filter(User.username == user_in.username).first():
            raise BusinessLogicException("Tên đăng nhập đã tồn tại")
        if db.query(User).filter(User.email == user_in.email).first():
            raise BusinessLogicException("Email đã được sử dụng")

        user = User(
            username=user_in.username,
            email=user_in.email,
            full_name=user_in.full_name,
            hashed_password=get_password_hash(user_in.password),
            role="student",
            is_active=True
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        
        token = create_access_token(subject=user.id)
        user_data = {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "is_active": user.is_active
        }
        return {
            "access_token": token,
            "token_type": "bearer",
            "user": user_data
        }

auth_service = AuthService()
