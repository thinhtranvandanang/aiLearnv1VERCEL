
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'https://esm.sh/react-router-dom@6';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { ROUTES } from './constants/routes';

// Import Pages
import { LandingPage } from './pages/public/LandingPage';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { DashboardPage } from './pages/student/DashboardPage';
import { CreateTestPage } from './pages/student/CreateTestPage';
import { TakeTestPage } from './pages/student/TakeTestPage';
import { OfflineSubmissionPage } from './pages/student/OfflineSubmissionPage';
import { ResultPage } from './pages/student/ResultPage';
import { SuggestionsPage } from './pages/student/SuggestionsPage';

/**
 * MainLayout: Cung cấp khung giao diện đồng nhất cho học sinh
 */
const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans antialiased text-gray-900">
      {/* Navigation Bar */}
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 flex justify-between h-16 items-center">
          <div 
            className="flex items-center gap-2 cursor-pointer select-none" 
            onClick={() => navigate(ROUTES.PROTECTED.DASHBOARD)}
          >
            <span className="text-2xl font-black text-indigo-600 italic tracking-tighter">EduNexia</span>
            <span className="bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter">STUDENT</span>
          </div>
          
          <div className="flex items-center gap-4 md:gap-6">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-sm font-bold text-gray-800">{user?.full_name}</span>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none">{user?.role}</span>
            </div>
            <button 
              onClick={logout}
              className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all border border-transparent hover:border-red-100"
              title="Đăng xuất"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
              </svg>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1">
        {children}
      </main>

      {/* Shared Footer */}
      <footer className="py-8 text-center text-gray-400 text-sm font-medium border-t bg-white">
        <p>&copy; 2024 EduNexia Learning Platform. All rights reserved.</p>
      </footer>
    </div>
  );
};

/**
 * AppRoutes: Thành phần chứa toàn bộ logic định tuyến
 */
const AppRoutes: React.FC = () => {
  const { token } = useAuth();

  return (
    <Routes>
      <Route path={ROUTES.PUBLIC.HOME} element={<LandingPage />} />

      <Route 
        path={ROUTES.PUBLIC.LOGIN} 
        element={token ? <Navigate to={ROUTES.PROTECTED.DASHBOARD} replace /> : <LoginPage />} 
      />

      <Route 
        path={ROUTES.PUBLIC.REGISTER} 
        element={token ? <Navigate to={ROUTES.PROTECTED.DASHBOARD} replace /> : <RegisterPage />} 
      />

      <Route path={ROUTES.PROTECTED.DASHBOARD} element={
        <ProtectedRoute>
          <MainLayout><DashboardPage /></MainLayout>
        </ProtectedRoute>
      } />

      <Route path={ROUTES.PROTECTED.PRACTICE_SETUP} element={
        <ProtectedRoute>
          <MainLayout><CreateTestPage /></MainLayout>
        </ProtectedRoute>
      } />

      <Route path={ROUTES.PROTECTED.PRACTICE_TEST} element={
        <ProtectedRoute>
          <TakeTestPage />
        </ProtectedRoute>
      } />

      <Route path={ROUTES.PROTECTED.PRACTICE_OFFLINE} element={
        <ProtectedRoute>
          <MainLayout><OfflineSubmissionPage /></MainLayout>
        </ProtectedRoute>
      } />

      <Route path={ROUTES.PROTECTED.RESULT} element={
        <ProtectedRoute>
          <MainLayout><ResultPage /></MainLayout>
        </ProtectedRoute>
      } />

      <Route path={ROUTES.PROTECTED.SUGGESTIONS} element={
        <ProtectedRoute>
          <MainLayout><SuggestionsPage /></MainLayout>
        </ProtectedRoute>
      } />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => (
  <AuthProvider>
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  </AuthProvider>
);

export default App;
