
import React, { useEffect } from 'react';
import { useNavigate } from 'https://esm.sh/react-router-dom@6';
import { useAuth } from '../context/AuthContext';
import { ROUTES } from '../constants/routes';

/**
 * RootRedirectPage: Thành phần bắt buộc xử lý route "/"
 * Mục đích: Kiểm tra trạng thái đăng nhập và điều hướng người dùng.
 */
export const RootRedirectPage: React.FC = () => {
  const { token, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Chỉ thực hiện điều hướng sau khi quá trình check auth ban đầu hoàn tất
    if (!isLoading) {
      if (token) {
        // Nếu có token, chuyển đến trang Dashboard chính
        navigate(ROUTES.PROTECTED.DASHBOARD, { replace: true });
      } else {
        // Nếu không, yêu cầu đăng nhập
        navigate(ROUTES.PUBLIC.LOGIN, { replace: true });
      }
    }
  }, [token, isLoading, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="flex flex-col items-center">
        {/* UI Loading nhẹ nhàng, chuyên nghiệp */}
        <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
        <div className="flex items-center gap-2">
          <span className="text-xl font-black text-indigo-600 italic tracking-tighter">EduNexia</span>
          <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Đang khởi tạo...</span>
        </div>
      </div>
    </div>
  );
};
