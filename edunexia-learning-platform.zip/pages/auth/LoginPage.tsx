
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'https://esm.sh/react-router-dom@6';
import { useAuth } from '../../context/AuthContext';
import { Card, LoadingOverlay } from '../../components/common/UI';
import { LoginForm } from '../../components/auth/LoginForm';
import { GoogleLoginButton } from '../../components/auth/GoogleLoginButton';
import { ROUTES } from '../../constants/routes';

export const LoginPage: React.FC = () => {
  const { isLoading, setTokenManually } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isVerifyingGoogle, setIsVerifyingGoogle] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const googleToken = params.get('token');
    
    if (googleToken) {
      setIsVerifyingGoogle(true);
      setTokenManually(googleToken);
      
      const timer = setTimeout(() => {
        navigate(ROUTES.PROTECTED.DASHBOARD, { replace: true });
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [location, navigate, setTokenManually]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 relative overflow-hidden">
      {(isLoading || isVerifyingGoogle) && <LoadingOverlay />}

      {/* Decorative Background */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-40">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-indigo-100 rounded-full blur-[120px]"></div>
        <div className="absolute -bottom-[10%] -right-[10%] w-[50%] h-[50%] bg-violet-100 rounded-full blur-[120px]"></div>
      </div>

      <Card className="max-w-md w-full p-10 relative z-10 shadow-2xl border-none ring-1 ring-black/5">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl mb-6 shadow-xl transform -rotate-3">
            <span className="text-3xl font-black text-white italic">E</span>
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">Chào mừng trở lại!</h1>
          <p className="text-gray-500 text-sm mt-2 font-medium">Đăng nhập vào hệ thống EduNexia</p>
        </div>

        {isVerifyingGoogle ? (
          <div className="py-12 text-center space-y-6">
            <div className="relative w-16 h-16 mx-auto">
                <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
            <p className="text-indigo-600 font-black">Đang xác thực với Google...</p>
          </div>
        ) : (
          <>
            <LoginForm />

            <div className="my-10 flex items-center gap-4">
              <div className="flex-1 h-px bg-gray-100"></div>
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Hoặc</span>
              <div className="flex-1 h-px bg-gray-100"></div>
            </div>

            <GoogleLoginButton />
            
            <div className="mt-10 text-center">
              <p className="text-sm text-gray-500 font-medium">
                Chưa có tài khoản? <Link to={ROUTES.PUBLIC.REGISTER} className="font-bold text-indigo-600 hover:underline">Đăng ký ngay</Link>
              </p>
            </div>
          </>
        )}
      </Card>
    </div>
  );
};
