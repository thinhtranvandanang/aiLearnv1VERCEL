
import React from 'react';
import { Link } from 'https://esm.sh/react-router-dom@6';
import { useAuth } from '../../context/AuthContext';
import { Card, LoadingOverlay } from '../../components/common/UI';
import { RegisterForm } from '../../components/auth/RegisterForm';
import { GoogleLoginButton } from '../../components/auth/GoogleLoginButton';
import { ROUTES } from '../../constants/routes';

export const RegisterPage: React.FC = () => {
  const { isLoading } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 relative overflow-hidden">
      {isLoading && <LoadingOverlay />}
      
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-40">
        <div className="absolute -top-[10%] -right-[10%] w-[50%] h-[50%] bg-indigo-100 rounded-full blur-[120px]"></div>
        <div className="absolute -bottom-[10%] -left-[10%] w-[50%] h-[50%] bg-violet-100 rounded-full blur-[120px]"></div>
      </div>

      <Card className="max-w-xl w-full p-8 relative z-10 shadow-2xl border-none ring-1 ring-black/5">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-indigo-600 rounded-2xl mb-4 shadow-lg">
            <span className="text-2xl font-black text-white italic">E</span>
          </div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Tham gia EduNexia</h1>
          <p className="text-gray-500 text-sm mt-1 font-medium">Bắt đầu hành trình học tập thông minh</p>
        </div>

        <RegisterForm />

        <div className="my-8 flex items-center gap-3">
          <div className="flex-1 h-px bg-gray-100"></div>
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Đăng ký nhanh với</span>
          <div className="flex-1 h-px bg-gray-100"></div>
        </div>

        <GoogleLoginButton />
        
        <div className="mt-8 text-center border-t pt-6">
          <p className="text-sm text-gray-500 font-medium">
            Đã có tài khoản? <Link to={ROUTES.PUBLIC.LOGIN} className="font-bold text-indigo-600 hover:underline">Đăng nhập</Link>
          </p>
        </div>
      </Card>
    </div>
  );
};
