
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'https://esm.sh/react-router-dom@6';
import { getTestContent } from '../../services/test.service';
import { submitOnline } from '../../services/submission.service';
import { TestContent, QuestionOut } from '../../types/test.types';
import { Card, Button, Badge, LoadingOverlay } from '../../components/common/UI';
import { ROUTES } from '../../constants/routes';

interface ProcessedQuestion extends Omit<QuestionOut, 'options'> {
  parsedOptions: Record<string, string>;
}

interface ProcessedTest extends Omit<TestContent, 'questions'> {
  questions: ProcessedQuestion[];
}

export const TakeTestPage: React.FC = () => {
  const { testId } = useParams<{ testId: string }>();
  const navigate = useNavigate();
  
  const [test, setTest] = useState<ProcessedTest | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [startTime] = useState(new Date().toISOString());

  useEffect(() => {
    if (!testId) return;
    const fetchTest = async () => {
      try {
        const res = await getTestContent(parseInt(testId));
        if (res.status === 'success' && res.data) {
          const processedQuestions: ProcessedQuestion[] = res.data.questions.map(q => ({
            ...q,
            parsedOptions: q.options ? JSON.parse(q.options) : { A: '', B: '', C: '', D: '' }
          }));
          
          setTest({
            ...res.data,
            questions: processedQuestions
          });
          setTimeLeft(res.data.duration_minutes * 60);
        } else {
          setError(res.message || 'Không thể tải đề thi');
        }
      } catch (err: any) {
        setError(err.message || 'Đã xảy ra lỗi khi kết nối máy chủ');
      } finally {
        setLoading(false);
      }
    };
    fetchTest();
  }, [testId]);

  useEffect(() => {
    if (timeLeft <= 0 || !test) return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          // Tự động nộp bài khi hết giờ
          autoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, test]);

  const autoSubmit = async () => {
    if (isSubmitting) return;
    handleSubmit(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSelectAnswer = (qId: number, option: string) => {
    setAnswers(prev => ({ ...prev, [qId.toString()]: option }));
  };

  const handleSubmit = async (isAuto = false) => {
    if (!isAuto && !confirm('Bạn có chắc chắn muốn nộp bài?')) return;
    if (!testId) return;

    setIsSubmitting(true);
    try {
      const res = await submitOnline(parseInt(testId), {
        answers,
        start_time: startTime,
        end_time: new Date().toISOString()
      });
      if (res.status === 'success' && res.data) {
        navigate(ROUTES.PROTECTED.RESULT.replace(':submissionId', res.data.submission_id.toString()));
      }
    } catch (err: any) {
      alert(err.message || 'Lỗi khi nộp bài');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <LoadingOverlay />;
  if (error) return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="bg-red-50 p-6 rounded-2xl text-center max-w-md">
        <p className="text-red-600 font-bold mb-4">{error}</p>
        <Button onClick={() => navigate(ROUTES.PROTECTED.DASHBOARD)}>Quay lại Dashboard</Button>
      </div>
    </div>
  );
  if (!test) return <div className="p-20 text-center">Không tìm thấy dữ liệu.</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="bg-white border-b sticky top-0 z-20 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
          <div className="flex items-center gap-4">
             <button onClick={() => navigate(-1)} className="text-gray-400 hover:text-indigo-600 transition">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
             </button>
             <div>
              <h1 className="font-black text-gray-900 leading-none truncate max-w-[200px] md:max-w-xs">{test.title}</h1>
              <Badge variant="info">{test.subject}</Badge>
            </div>
          </div>
          <div className="flex items-center gap-4">
             <Button variant="outline" className="hidden lg:flex" onClick={() => navigate(ROUTES.PROTECTED.PRACTICE_OFFLINE.replace(':testId', testId!))}>
               Nộp bài Offline
             </Button>
             <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-mono font-bold text-lg md:text-xl ${timeLeft < 300 ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-gray-100 text-gray-700'}`}>
               <span className="hidden md:inline">⏱️</span> {formatTime(timeLeft)}
             </div>
             <Button onClick={() => handleSubmit()} isLoading={isSubmitting}>Nộp bài</Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-4 gap-8 flex-1 w-full">
        <div className="lg:col-span-3 space-y-8">
          {test.questions.map((q, idx) => (
            <Card key={q.id} className="p-8">
              <div className="flex gap-4 mb-6">
                <span className="w-10 h-10 bg-indigo-600 text-white rounded-lg flex items-center justify-center font-bold flex-shrink-0">
                  {idx + 1}
                </span>
                <div className="text-lg text-gray-800 font-medium leading-relaxed">
                  {q.content}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ml-0 md:ml-14">
                {Object.entries(q.parsedOptions).map(([key, value]) => (
                  <button
                    key={key}
                    onClick={() => handleSelectAnswer(q.id, key)}
                    className={`p-4 rounded-xl border-2 text-left transition flex items-center gap-3 ${
                      answers[q.id.toString()] === key 
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-200' 
                        : 'border-gray-100 hover:border-gray-300'
                    }`}
                  >
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                      answers[q.id.toString()] === key ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-500'
                    }`}>
                      {key}
                    </span>
                    <span className="font-medium">{value}</span>
                  </button>
                ))}
              </div>
            </Card>
          ))}
        </div>

        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-24">
            <h3 className="font-bold text-gray-800 mb-4">Danh sách câu hỏi</h3>
            <div className="grid grid-cols-5 gap-2">
              {test.questions.map((q, idx) => (
                <button
                  key={q.id}
                  onClick={() => {
                    document.getElementById(`question-${q.id}`)?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-xs transition ${
                    answers[q.id.toString()] 
                      ? 'bg-indigo-600 text-white' 
                      : 'bg-gray-100 text-gray-400 border border-transparent hover:border-indigo-300'
                  }`}
                >
                  {idx + 1}
                </button>
              ))}
            </div>
            <div className="mt-8 pt-6 border-t space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Đã trả lời:</span>
                <span className="font-bold text-indigo-600">{Object.keys(answers).length}/{test.questions.length}</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-2">
                <div 
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-500" 
                  style={{ width: `${(Object.keys(answers).length / (test.questions.length || 1)) * 100}%` }}
                ></div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
