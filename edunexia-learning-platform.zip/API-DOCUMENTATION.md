# API Documentation - EduNexia

## 1. Introduction
### 1.1 Overview
EduNexia là hệ thống quản lý học tập thông minh tập trung vào trải nghiệm luyện tập và phân tích kết quả bài làm cho học sinh. Hệ thống hỗ trợ cả hình thức làm bài trực tuyến (Online) và ngoại tuyến (Offline) qua ảnh chụp.

### 1.2 Tech Stack
- **Framework:** FastAPI (Python 3.10+)
- **Database:** PostgreSQL
- **ORM:** SQLAlchemy 2.0
- **Migration:** Alembic
- **Security:** JWT (JSON Web Token), OAuth2 with Password Flow, Bcrypt hashing.

### 1.3 Base URL
- **Local:** `http://localhost:8000/api/v1`
- **Production:** `https://edunexia-api.render.com/api/v1` (Giả định)

---

## 2. Getting Started
### 2.1 Installation
```bash
pip install -r requirements.txt
```

### 2.2 Environment Setup
Copy `.env.example` thành `.env` và cập nhật các biến:
- `DATABASE_URL`: Kết nối PostgreSQL.
- `SECRET_KEY`: Khóa bí mật để ký JWT.

### 2.3 Migration
```bash
alembic upgrade head
```

---

## 3. Authentication
### 3.1 Overview
Hệ thống sử dụng JWT Bearer Token. Token phải được đính kèm trong Header của mỗi request yêu cầu xác thực.

### 3.2 How to Login
Sử dụng endpoint `/auth/student/login` để lấy `access_token`.

### 3.3 Using Access Token
Header format:
`Authorization: Bearer <your_access_token>`

---

## 4. API Reference

### 4.1 Authentication APIs (UC1)
#### **Student Login**
- **Endpoint:** `POST /auth/student/login`
- **Payload:**
  ```json
  {
    "username": "student_01",
    "password": "secret_password"
  }
  ```
- **Response:** `APIResponse` chứa `access_token` và thông tin `user`.

### 4.2 Practice Test APIs (UC2, UC3, UC4)
#### **Generate Test**
- **Endpoint:** `POST /practice-tests/generate`
- **Payload:** `TestGenerateRequest` {subject, topic, level, question_count}
- **Role:** Student

#### **Get Test Content**
- **Endpoint:** `GET /practice-tests/{testId}/content`
- **Description:** Lấy danh sách câu hỏi và metadata của đề.

#### **Download Test (Offline)**
- **Endpoint:** `GET /practice-tests/{testId}/download`
- **Params:** `format` (pdf/docx)
- **Response:** Trả về URL tải file.

### 4.3 Submission APIs (UC3, UC4)
#### **Submit Online**
- **Endpoint:** `POST /practice-tests/{testId}/submit-online`
- **Payload:** 
  ```json
  {
    "answers": {"1": "A", "2": "C"},
    "start_time": "ISO_TIMESTAMP",
    "end_time": "ISO_TIMESTAMP"
  }
  ```

#### **Submit Offline**
- **Endpoint:** `POST /practice-tests/{testId}/submit-offline`
- **Format:** `multipart/form-data`
- **Field:** `file` (Image/PDF)

### 4.4 Result & Analytics APIs (UC5, UC6)
#### **View Results**
- **Endpoint:** `GET /submissions/{submissionId}/result`
- **Description:** Trả về điểm số, số câu đúng/sai và giải thích chi tiết từng câu.

#### **Get Learning Suggestions**
- **Endpoint:** `GET /submissions/{submissionId}/learning-suggestions`
- **Description:** Gợi ý các kiến thức cần ôn tập dựa trên các câu sai.

### 4.5 Student Progress APIs (UC7)
#### **Learning History**
- **Endpoint:** `GET /students/me/learning-history`
- **Description:** Danh sách các bài đã làm và thống kê xu hướng tiến bộ.

#### **History Detail**
- **Endpoint:** `GET /students/me/learning-history/{submissionId}`
- **Description:** Xem lại chi tiết kết quả của một bài làm cũ.

---

## 5. Error Handling
### 5.1 Error Response Format
Tất cả lỗi được trả về dưới dạng:
```json
{
  "status": "error",
  "message": "Chi tiết thông báo lỗi bằng Tiếng Việt"
}
```

### 5.2 Common Error Codes
- `401 Unauthorized`: Token hết hạn hoặc không hợp lệ.
- `403 Forbidden`: Không có quyền truy cập dữ liệu của học sinh khác.
- `404 Not Found`: Không tìm thấy Đề luyện tập hoặc Bài làm.
- `400 Bad Request`: Sai logic nghiệp vụ (ví dụ: nộp bài 2 lần cho 1 đề).

---

## 6. Appendix
### 6.1 Data Models
- **User:** Lưu account và profile.
- **Question:** Ngân hàng câu hỏi theo môn/chủ đề.
- **PracticeTest:** Đề thi được lắp ráp từ Question.
- **Submission:** Bài làm của học sinh (Online/Offline).
- **GradingResult:** Kết quả chấm và feedback.
- **LearningSuggestion:** Gợi ý cải thiện.

### 6.2 Health Check
`GET /health` -> `{"status": "ok", "service": "EduNexia API"}`
