
# EduNexia Learning Platform

Nền tảng học tập thông minh cá nhân hóa lộ trình dựa trên AI.

## Công nghệ sử dụng
- **Backend:** FastAPI, SQLAlchemy 2.0, PostgreSQL, Google OAuth 2.0.
- **Frontend:** React 19, Tailwind CSS, Axios, React Router 6.

## Luồng Xác thực (Authentication Flow)
Hệ thống hỗ trợ 2 hình thức đăng nhập:
1. **Truyền thống:** Sử dụng Username/Password.
2. **Google OAuth:** Redirect sang Google -> Backend Exchange Code -> Backend Trả về JWT Token qua URL Redirect.

## Danh sách màn hình & API

| Màn hình | Route | API Endpoint | Thành phần (Components) |
| :--- | :--- | :--- | :--- |
| **Landing Page** | `/` | - | `Navbar`, `Hero`, `Features`, `Stats` |
| **Login** | `/login` | `POST /auth/student/login` <br> `GET /auth/google/login` | `LoginForm`, `GoogleLoginButton` |
| **Register** | `/register` | `POST /auth/student/register` | `RegisterForm`, `GoogleLoginButton` |
| **Dashboard** | `/dashboard` | `GET /students/me/learning-history` <br> `GET /auth/student/me` | `StatsGrid`, `HistoryTable`, `AIQuickAction` |
| **Tạo Đề** | `/practice/setup` | `POST /practice-tests/generate` | `TestConfigForm`, `AICoachMessage` |
| **Làm Bài** | `/practice/:id` | `GET /practice-tests/{id}/content` <br> `POST /practice-tests/{id}/submit-online` | `QuizEngine`, `FloatingTimer`, `QNavigator` |
| **Nộp Bài Offline**| `/practice/:id/offline`| `POST /practice-tests/{id}/submit-offline` | `ImageUploader`, `OCRPreview` |
| **Kết Quả** | `/results/:id` | `GET /submissions/{id}/result` | `ScoreCircular`, `FeedbackList`, `ExplanationCard` |
| **Gợi Ý AI** | `/results/:id/suggestions` | `GET /submissions/{id}/learning-suggestions` | `PathRecommendation`, `StudyMaterialLinks` |

## Hướng dẫn cài đặt Backend
1. Cấu hình `.env` với `GOOGLE_CLIENT_ID` và `GOOGLE_CLIENT_SECRET`.
2. Chạy `pip install -r requirements.txt`.
3. Chạy `alembic upgrade head`.
4. Khởi động: `python -m app.main`.
