
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserOut, LoginRequest, UserCreate } from '../types/auth.types';
import * as authService from '../services/auth.service';
import * as studentService from '../services/student.service';

interface AuthContextType {
  user: UserOut | null;
  token: string | null;
  isLoading: boolean;
  login: (credentials: LoginRequest) => Promise<void>;
  register: (data: UserCreate) => Promise<void>;
  logout: () => void;
  setTokenManually: (token: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserOut | null>(() => {
    const savedUser = localStorage.getItem('edunexia_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [token, setToken] = useState<string | null>(localStorage.getItem('edunexia_token'));
  const [isLoading, setIsLoading] = useState(false);

  const fetchProfile = useCallback(async (authToken: string) => {
    try {
      const res = await studentService.getMe();
      if (res.status === 'success' && res.data) {
        setUser(res.data);
        localStorage.setItem('edunexia_user', JSON.stringify(res.data));
      }
    } catch (error) {
      console.error("Auth: Failed to fetch user profile", error);
      // Chỉ logout nếu thực sự lỗi xác thực
      if (token) logout();
    }
  }, [token]);

  useEffect(() => {
    if (token && !user) {
      fetchProfile(token);
    }
  }, [token, user, fetchProfile]);

  const handleAuthSuccess = (data: any) => {
    const { access_token, user: userData } = data;
    setToken(access_token);
    setUser(userData || null);
    localStorage.setItem('edunexia_token', access_token);
    if (userData) {
      localStorage.setItem('edunexia_user', JSON.stringify(userData));
    }
  };

  const login = async (credentials: LoginRequest) => {
    setIsLoading(true);
    try {
      const response = await authService.login(credentials);
      if (response.status === 'success' && response.data) {
        handleAuthSuccess(response.data);
      } else {
        throw new Error(response.message || 'Đăng nhập thất bại');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: UserCreate) => {
    setIsLoading(true);
    try {
      const response = await authService.register(data);
      if (response.status === 'success' && response.data) {
        handleAuthSuccess(response.data);
      } else {
        throw new Error(response.message || 'Đăng ký thất bại');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const setTokenManually = (newToken: string) => {
    localStorage.setItem('edunexia_token', newToken);
    setToken(newToken);
    // Profile sẽ được useEffect bắt và fetch tự động
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('edunexia_token');
    localStorage.removeItem('edunexia_user');
    window.location.href = '/login';
  };

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, register, logout, setTokenManually }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
